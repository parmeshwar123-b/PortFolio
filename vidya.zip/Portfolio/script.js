function validateForm() {
    let x = document.forms["myForm"]["name"].value;
    if (x == "") {
      alert("Pahala Naam Daaal");
      return false;
    }
    let y = document.forms["myForm"]["email"].value;
    if (y == "") {
      // alert("Email must be filled out");
      alert("Pahala  Email daal");
      return false;
    }
  }



